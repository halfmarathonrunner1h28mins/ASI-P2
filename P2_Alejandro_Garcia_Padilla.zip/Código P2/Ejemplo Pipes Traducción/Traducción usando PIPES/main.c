#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>

#define MSG_SIZE 1024
void quitarSalto(char *cadena);
void toMayus(char *cadena);
int main(int argc, char** argv) {
    int fed[2];
    int fed1[2];
    pid_t hijo1, hijo2;
    pipe(fed);
    pipe(fed1);
    
    /*Creamos hijo 1 y comprobamos si es el*/
    hijo1 = fork();
    
    if(hijo1 == 0){
        
        close(fed[0]);/*Queremos que de esta escriba*/
        close(fed1[1]);/*Queremos que de esta lea*/
        /*Declaramos el mensaje a escribir*/
        char men [MSG_SIZE];
        char men1 [MSG_SIZE];
        int respuesta;
        printf("Introduzca el mensaje que desea escribir: \n");
        __fpurge(stdin); /*Limpiar buffers*/
        fgets(men, sizeof(men), stdin);
        quitarSalto(men);
        write(fed[1],men,sizeof(men)); /*Un array ya es de por si un puntero*/
        if(read(fed1[0], men1,sizeof(men1))>0){
            printf("Mensaje traducido: %s", men1);
        }
        exit(EXIT_SUCCESS);
    }
    else{ /*Soy el padre*/
        
        hijo2 = fork();
        if(hijo2 == 0){
            /*Declaramos el mensaje a leer*/
            char men [MSG_SIZE];
            close(fed[1]);/*Solo queremos que lea*/
            close(fed1[0]);/*Queremos que de esta otra escriba*/
            /*Comprobamos que hay info a leer*/
            if(read(fed[0],men, sizeof(men))>0){
                toMayus(men);
                write(fed1[1],men,sizeof(men));
            }
        }else{
            wait(NULL);
            wait(NULL);
            exit(EXIT_SUCCESS);
        }
    }
    return (EXIT_SUCCESS);
}
void quitarSalto(char *cadena){
    if(cadena[strlen(cadena - 1)]== '\n'){
       cadena[strlen(cadena - 1)]== '\0';
    }
}

void toMayus(char *cadena){
    int i = 0;
    char c;
    while(cadena[i]){
        c = cadena[i];
        cadena[i] = toupper(c);
        i++;
    }
}

