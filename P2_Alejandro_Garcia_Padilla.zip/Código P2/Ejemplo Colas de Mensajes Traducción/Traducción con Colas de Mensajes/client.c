#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include <strings.h>
#include <string.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <unistd.h>
#define TAM 256
#define CLAVE 0x12345L

/*Declaramos las estructuras*/

typedef struct mensaje1{ /*typedef --> para que la variable ahora se pueda llamar MENSAJET1*/
    long canal;
    int canal_resp;
    char mensaje[TAM]; 
}MENSAJET1;

typedef struct mensaje2{ /*typedef --> para que la variable ahora se pueda llamar MENSAJET2*/
    long canal;
    char mensaje[TAM]; 
}MENSAJET2;

int main(int argc, char** argv) {
    /*Lo primero --> Crear el buzón --> Lo hacemos tanto en cliente como en 
    servidor por seguridad*/
    int buzid; /*Identificador del buzon*/
    buzid = msgget(CLAVE, IPC_CREAT|0666);
    /*Vamos a pedir el mensaje a enviar y a enviarlo*/
    MENSAJET1 men1;
    MENSAJET2 men2;
    men1.canal = 1; /*Canal de envio del cliente == 1*/
    men1.canal_resp = getpid(); /*El canal del buzon del que recibiremos la respuesta*/
    printf("Introduzca el mensaje a ser convertido: \n");
    fgets(men1.mensaje, sizeof(men1.mensaje), stdin);/*El mensaje a enviar*/
    msgsnd(buzid, &men1,sizeof(men1) - sizeof(long), 0);/*Hay que indicarle la dirección de dicha variable --& por delante*/
                                                        /*El tamaño es el de la información*/
    printf("El mensaje enviado es: %s \n", men1.mensaje);
    msgrcv(buzid, &men2,sizeof(men2) - sizeof(long), getpid(),0); /*Recibimos del canal indicado en el campo int del primero*/
    printf("El mensaje recibido es: %s \n", men2.mensaje);/*Presentamos por pantalla*/

    return (EXIT_SUCCESS);
}

