#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include <string.h>
#include <strings.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <unistd.h>
#include <sys/msg.h>
#include <ctype.h>
#define TAM 256
#define CLAVE 0x12345L

void toMayus(char *cadena);
/*Declaramos las estructuras*/

typedef struct mensaje1{ /*typedef --> para que la variable ahora se pueda llamar MENSAJET1*/
    long canal;
    int canal_resp;
    char mensaje[TAM]; 
}MENSAJET1;

typedef struct mensaje2{ /*typedef --> para que la variable ahora se pueda llamar MENSAJET2*/
    long canal;
    char mensaje[TAM]; 
}MENSAJET2;


int main(int argc, char** argv) {
    
    int buzid; /*Identificador del buzon*/
    buzid = msgget(CLAVE, IPC_CREAT|0666);
    /*Vamos a leer el mensaje enviado*/
    MENSAJET1 men1;
    MENSAJET2 men2;
    
    
    msgrcv(buzid, &men1,sizeof(men1) - sizeof(long), 1 ,0);
    printf("El mensaje recibido es: %s \n", men1.mensaje);/*Presentamos por pantalla*/

    men2.canal = (long)men1.canal_resp;
    toMayus(men1.mensaje);
    strcpy(men2.mensaje,men1.mensaje);
    msgsnd(buzid, &men2, sizeof(men2) - sizeof(long), 0);
    printf("El mensaje enviado es: %s \n", men2.mensaje);


    return (EXIT_SUCCESS);
}

void toMayus(char *cadena){
    int i = 0;
    char c;
    while(cadena[i]){
        c = cadena[i];
        cadena[i] = toupper(c);
        i++;
    }
}

