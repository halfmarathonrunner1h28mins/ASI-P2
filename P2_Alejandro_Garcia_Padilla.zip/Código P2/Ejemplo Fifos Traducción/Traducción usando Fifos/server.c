#include <fcntl.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>
#include <ctype.h>

#define MAXTAM 256
void toMayus(char *cadena);
int main(int argc, char** argv) {
    
    mkfifo("cliente_servidor", 0666);
    mkfifo("servidor_cliente", 0666);
    char men [MAXTAM];
    char men3[4] = "NACK";
    int fifoid;
    int fifoid2;

    fifoid = open("cliente_servidor", O_RDONLY);/*Abrimos el pipe*/
    
    if(read(fifoid, men, sizeof(men))>0){ /*Leemos y presentamos por pantalla*/
        printf("Received %s\n", men);
        unlink("cliente_servidor");/*Cerramos pipe*/
        fifoid2 = open("servidor_cliente", O_WRONLY);
        toMayus(men);
        write(fifoid2, men, sizeof(men));
    }
    
    else{
        if(read(fifoid, men, sizeof(men))== -1){ /*Leemos y presentamos por pantalla*/
        printf("INCORRECT\n");
        unlink("cliente_servidor");/*Cerramos pipe*/
        fifoid2 = open("servidor_cliente", O_WRONLY);
        write(fifoid2, men3, sizeof(men3));
        }
        
    }
    



    return (EXIT_SUCCESS);
}

void toMayus(char *cadena){
    int i = 0;
    char c;
    while(cadena[i]){
        c = cadena[i];
        cadena[i] = toupper(c);
        i++;
    }
}