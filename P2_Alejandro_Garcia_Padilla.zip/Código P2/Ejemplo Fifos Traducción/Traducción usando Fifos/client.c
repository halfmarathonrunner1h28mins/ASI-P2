#include <fcntl.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>
#include <ctype.h>

#define MAXTAM 256
void quitarSalto(char *cadena);

int main(int argc, char** argv) {
    
    mkfifo("cliente_servidor", 0666);
    mkfifo("servidor_cliente", 0666);
    char men [MAXTAM];
    char men2 [MAXTAM];
    int fifoid;
    int fifoid2;
    
    printf("Introduzca el mensaje que desea enviar al servidor:\n");
    __fpurge(stdin);
    fgets(men, sizeof(men), stdin);
    quitarSalto(men);
    
    fifoid = open("cliente_servidor", O_WRONLY);/*Abrimos el pipe*/
    write(fifoid, men, sizeof(men));
    
    
    fifoid2 = open("servidor_cliente", O_RDONLY);/*Abrimos el pipe*/
    if(read(fifoid2, men2, sizeof(men2))>0){ /*Leemos y presentamos por pantalla*/
        printf("Received %s\n", men2);
        unlink("servidor_cliente"); /*Cerramos el pipe*/
    }

    return (EXIT_SUCCESS);
}

void quitarSalto(char *cadena){
    if(cadena[strlen(cadena - 1)]== '\n'){
       cadena[strlen(cadena - 1)]== '\0';
    }
}

