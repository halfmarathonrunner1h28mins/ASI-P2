/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/main.c to edit this template
 */

/* 
 * File:   client.c
 * Author: alex
 *
 * Created on 4 de marzo de 2024, 8:28
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <string.h>

#define PERMISIONS 0666
#define TAM 256 /*El /0 del final de la cadena que te envia también cuenta*/
#define CLAVE 0x79295875L

typedef struct mensaje1{ /*typedef --> para que la variable ahora se pueda llamar MENSAJET1*/
    long canal;
    char cs3[TAM]; 
    char cs4[TAM];
}MENSAJET1;

typedef struct mensaje2{ /*typedef --> para que la variable ahora se pueda llamar MENSAJET2*/
    long canal;
    char cs4[TAM];
}MENSAJET2;


void ejercicio1(int fifoid);
void ejercicio2(int fifoid);
void espera(int *ejercicio);
void ejercicio3();
void ejercicio4();
void ejercicio5();
void ejercicio6(int pidmon);
void ejercicio7(int pidmon);
/*Variables globales*/
char sec1 [TAM]; /*Para guardar el secreto 1*/
char sec2 [TAM]; /*Para guardar el secreto 2 y poder enviar el eco*/
char sec3 [TAM]; /*Para guardar el secreto 3*/
char sec4 [TAM]; /*Para guardar el secreto 4*/
char sec6 [TAM]; /*Para guardar el secreto 6*/
int fifoid; /*Para guardar un identificador global del fifo1*/
int fifoid2; /*Para guardar un identificador global del fifo2*/

int main(int argc, char** argv) {
    
    int pidmon = atoi(argv[1]);
    
    int ejercicio = 1;
    /*Ejercicio 1*/
    /*Apertura del fifo1*/
    espera(&ejercicio);
    fifoid = open("/tmp/fifo_monitor_1", O_RDONLY);
    ejercicio1(fifoid);
    
    /*Ejercicio 2*/
    espera(&ejercicio);
    ejercicio2(fifoid);
    
    /*Ejercicio 3*/
    espera(&ejercicio);
    ejercicio3();
    
    /*Ejercicio 4*/
    espera(&ejercicio);
    ejercicio4();
    
    /*Ejercicio 5*/
    espera(&ejercicio);
    ejercicio5();
    
    /*Ejercicio 6*/
    espera(&ejercicio);
    ejercicio6(pidmon);
    
    /*Ejercicio 7*/
    espera(&ejercicio);
    ejercicio7(pidmon);
    
    return (EXIT_SUCCESS);
}

/*Función para permitir saltos*/
void espera(int *ejercicio){ /*Será puntero para poder modificarla*/
    printf("Pulsa tecla para ejecutar ejercicio %d :\n", *ejercicio);
    __fpurge(stdin);
    getchar();
    (*ejercicio)++; 
}

/*************/
/*Ejercicio 1*/
/*************/

void ejercicio1(int fifoid){
    read(fifoid,sec1,sizeof(sec1));
    printf("El secreto 1 es : %s \n", sec1);
}

/*************/
/*Ejercicio 2*/
/*************/

void ejercicio2(int fifoid){
    /*Creamos el segundo fifo*/
    mkfifo("/tmp/fifo_monitor_2", PERMISIONS);
    fifoid2 = open("/tmp/fifo_monitor_2", O_WRONLY);
    sleep(1);
    write(fifoid2, sec1, sizeof(sec1)); /*Le mandamos el secreto 1*/
    /*Leemos el secreto 2 del fifo1*/
    sleep(5);
    if(read(fifoid, sec2, sizeof(sec2))<= 0){
        printf("Show me the error mate...\n");
    }
    else{
        printf("El secreto 2 es: %s\n", sec2);
        /*Le respondemos via un eco*/
        write(fifoid2, sec2, sizeof(sec2));
    }
}

/*************/
/*Ejercicio 3*/
/*************/

void ejercicio3(){
    int secr3;
    int buzid; /*Identificador general del buzón*/
    MENSAJET2 men1;
    
    buzid = msgget(CLAVE, PERMISIONS); /*Sin el flag IPC_CREAT --> Ya esta creada*/
    
    msgrcv(buzid, &men1, sizeof(men1)-sizeof(long),0,0); /*Pongo un 0 en el canal para no discriminar --> No conozco el canal por el que lo manda*/
    secr3 = (int)men1.canal;
    sprintf(sec3,"<%d>",secr3); /*Para meter el secreto 3*/
    strcpy(sec4, men1.cs4);
    printf("El secreto 3 es: %s y el 4 es: %s\n", sec3, sec4);

}

/*************/
/*Ejercicio 4*/
/*************/

void ejercicio4(){

    int buzid; /*Identificador general del buzón*/
    char aux[TAM];
    MENSAJET2 men1;
    buzid = msgget(CLAVE, IPC_CREAT|PERMISIONS); /*Sin el flag IPC_CREAT --> Ya esta creada*/
    /*Rellenamos los campos del mensaje*/
    men1.canal = 1; /*Da igual el canal*/
    strcpy(aux, sec3);
    strcat(aux, sec4); /*Concateno el sec 3 y el 4 en aux*/
    strcpy(men1.cs4, aux);
    msgsnd(buzid, &men1, sizeof(men1)-sizeof(long),0); /*Pongo un 0 en el canal para no discriminar --> No conozco el canal por el que lo manda*/
    printf("ENDED 4\n");
}

/*************/
/*Ejercicio 5*/
/*************/

void ejercicio5(){
    int buzid; /*Identificador general del buzón*/
    buzid = msgget(CLAVE, PERMISIONS); /*Sin el flag IPC_CREAT --> Ya esta creada*/
    MENSAJET2 men1;
    msgrcv(buzid, &men1, sizeof(men1)-sizeof(long), getpid(), 0); /*Getpid() para usar la cola / canal  con el pid del cliente*/
    strcpy(sec6, men1.cs4);
    printf("El secreto 6 es: %s\n", sec6);
}

/*************/
/*Ejercicio 6*/
/*************/

void ejercicio6(int pidmon){
    int buzid; /*Identificador general del buzón*/
    buzid = msgget(CLAVE, PERMISIONS); /*Sin el flag IPC_CREAT --> Ya esta creada*/
    MENSAJET2 men1;
    men1.canal = pidmon;
    strcpy(men1.cs4, sec6);
    msgsnd(buzid, &men1, sizeof(men1)-sizeof(long), 0); 
    printf("ENDED 6\n");
}

/*************/
/*Ejercicio 7*/
/*************/

void ejercicio7(int pidmon){
    int buzid; /*Identificador general del buzón*/
    buzid = msgget(CLAVE, PERMISIONS); /*Sin el flag IPC_CREAT --> Ya esta creada*/
    MENSAJET2 men1;
    men1.canal = pidmon;
    strcpy(men1.cs4, "BYE BYE");
    msgsnd(buzid, &men1, sizeof(men1)-sizeof(long), 0); 
    /*Cerrar colas de mensajes y fifos*/
    unlink("/tmp/fifo_monitor_1");
    unlink("/tmp/fifo_monitor_2");
    msgctl(buzid, IPC_RMID, NULL);
    printf("ENDED 7\n");
}